<?php
header('Location: admin/');
?>